package com.example.wallapop

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wallapop.databinding.ActivityRegistroMailBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class Registro_mail : AppCompatActivity() {

    private lateinit var binding : ActivityRegistroMailBinding

    //firebase autenticathion
    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroMailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Espera por favor")
        progressDialog.setCanceledOnTouchOutside(false)


        //acceder al boton de registrar
        binding.BtnRegistrar.setOnClickListener{
            validarInfo()
        }

    }

    //strings que guarda info del ususario: corroe, pass, pass repetida
    private var email = ""
    private var contrasena = ""
    private var rep_contrasena = ""

    private fun validarInfo() {

        email = binding.StringMail.text.toString().trim()
        contrasena = binding.StringPassword.text.toString().trim()
        rep_contrasena = binding.EditextRepetirPassword.text.toString().trim()

        //validar info recogida
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            binding.StringMail.error = "Email incorrecto"
            binding.StringMail.requestFocus()
        }
        //email vacio
        else if (email.isEmpty()){
            binding.StringMail.error = "Introduce tu email"
            binding.StringMail.requestFocus()
        }
        //password vacio
        else if (contrasena.isEmpty()){
            binding.StringPassword.error = "Introduce la contraseña"
            binding.StringPassword.requestFocus()
        }
        else if (rep_contrasena.isEmpty()) {
            binding.EditextRepetirPassword.error = "Repite la contraseña introducida"
            binding.EditextRepetirPassword.requestFocus()
        }
        //comprobar si es distinta la pass de la pass repetida
        else if (contrasena != rep_contrasena){
            binding.EditextRepetirPassword.error = "Las contraseñas introducidas no coinciden"
            binding.EditextRepetirPassword.requestFocus()

        }
        else{
            registrarUsuario()
        }

    }

    private fun registrarUsuario() {
        progressDialog.setMessage("Creando tu cuenta...")
        progressDialog.show()//mostramos

        firebaseAuth.createUserWithEmailAndPassword(email,contrasena)//propiedad de firebase para crear el user con su pass
            //registro ok
            .addOnSuccessListener {
            guardarInfoBd()
            }
            //registro no ok
            .addOnFailureListener {e->
                progressDialog.dismiss()
                //toast para enseñar el error
                Toast.makeText(
                    this,
                    "Registro fallido,${e.message}",
                    Toast.LENGTH_SHORT).show()

            }

    }

    private fun guardarInfoBd() {
        progressDialog.setMessage("Guardando info...")
        //Datos del user

        val tiempo = FuncionesConstates.obtenerTiempoDispositivo()
        //obtener mail de user registrado
        val emailUser = firebaseAuth.currentUser!!.email
        val  uidUsuario = firebaseAuth.uid

        val hashMap = HashMap<String, Any>()
        hashMap["nombres"] = ""
        hashMap["codTelefono"] = ""
        hashMap["telefono"] = ""
        hashMap["urlFotoPerfil"] = ""
        hashMap["proveedorAcceso"] = "Email"
        hashMap["escribiendoChat"] = ""
        hashMap["tiempo"] = tiempo
        hashMap["online"] = "true" //estado de user
        hashMap["mail"] = "${emailUser}"
        hashMap["uid"] = "${uidUsuario}"
        hashMap["fecha_nacimiento"] = ""

        //envio datos recogidos a firebase
        val ref = FirebaseDatabase.getInstance().getReference("Usuarios") //nombre bbdd
        ref.child(uidUsuario!!)
            .setValue(hashMap)//con esto le pasamos toda la info almacenada en el hasmpa dentro del iuid del user
            //registro usuario ok
            .addOnSuccessListener {
                progressDialog.dismiss()
                startActivity(Intent(this, MainActivity::class.java))
                finishAffinity()
            }
            //regustro usuario fallido
            .addOnFailureListener {e->
                progressDialog.dismiss()
                Toast.makeText(
                    this,
                    "No se ha registrado. Fallo: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }
}