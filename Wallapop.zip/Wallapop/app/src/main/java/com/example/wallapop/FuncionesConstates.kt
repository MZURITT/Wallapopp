package com.example.wallapop

import android.icu.text.DateFormat
import android.icu.util.Calendar
import java.util.Locale

object FuncionesConstates {

    //guardar tiempo de ejecucion del movil y guardar hora de registro del user
    fun obtenerTiempoDispositivo() : Long{
        return System.currentTimeMillis()
    }

    //obtener dia, mes y año a traves de un tiempo
    fun obtenerFecha(tiempo : Long)  : String {
        val calendario = Calendar.getInstance(Locale.ENGLISH)
        calendario.timeInMillis = tiempo

        return DateFormat.format("dd/MM/yyyy", calendario).toString()
    }
}