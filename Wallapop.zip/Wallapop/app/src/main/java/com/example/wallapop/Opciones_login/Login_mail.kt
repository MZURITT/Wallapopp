package com.example.wallapop.Opciones_login

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wallapop.MainActivity
import com.example.wallapop.R
import com.example.wallapop.Registro_mail
import com.example.wallapop.databinding.ActivityLoginMailBinding
import com.example.wallapop.databinding.ActivityRegistroMailBinding
import com.google.firebase.auth.FirebaseAuth

class Login_mail : AppCompatActivity() {

    private lateinit var binding: ActivityLoginMailBinding

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginMailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Un momento,...")
        progressDialog.setCanceledOnTouchOutside(false)

        //evento al boton
        binding.BtnAcceder.setOnClickListener{
            validarInfo()
        }


        binding.TxtRegistrarse.setOnClickListener{
            startActivity(Intent(this@Login_mail, Registro_mail::class.java))
        }

    }

    // variable spara guardar email y pass
    private var email = ""
    private var contrasena = ""
    private fun validarInfo() {
        email = binding.StringMail.text.toString().trim()
        contrasena = binding.StringPassword.text.toString().trim()

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            binding.StringMail.error = "Email incorrecto"
            binding.StringMail.requestFocus()
        }
        else if (email.isEmpty()){
            binding.StringMail.error = "Introduce tu email"
            binding.StringMail.requestFocus()
        }
        else if (contrasena.isEmpty()){
            binding.StringPassword.error = "Introduce tu contraseña"
            binding.StringPassword.requestFocus()
        }
        else{
            loginUsuario()
        }


    }

    private fun loginUsuario() {
        progressDialog.setMessage("Accediendo...")
        progressDialog.show()

        firebaseAuth.signInWithEmailAndPassword(email, contrasena)
            //si todo esta ok
            .addOnSuccessListener {e->
                progressDialog.dismiss()
                startActivity(Intent(this, MainActivity::class.java))
                finishAffinity()
                Toast.makeText(
                    this,
                    "Bienvenid@!",
                    Toast.LENGTH_SHORT
                ).show()

            }
            // si da error
            .addOnFailureListener{e->
                progressDialog.dismiss()
                Toast.makeText(
                    this,
                    "No se ha podido iniciar sesion. Error: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }
}