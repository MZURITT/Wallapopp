package com.example.wallapop

import android.app.Activity
import android.app.ProgressDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.example.wallapop.databinding.ActivityEditarPerfilBinding
import com.example.wallapop.databinding.FragmentCuentaBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class EditarPerfil : AppCompatActivity() {

    private lateinit var binding: ActivityEditarPerfilBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var progressDialog: ProgressDialog


    private var imageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditarPerfilBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //firebaSE instancia
        firebaseAuth = FirebaseAuth.getInstance()

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Espera un momento...")
        progressDialog.setCanceledOnTouchOutside(false)

        cargarInfo()

        binding.floatActionButtonCambiarImg.setOnClickListener {
            select_img_de()
        }

    }

    private fun cargarInfo() {
        val ref = FirebaseDatabase.getInstance().getReference("Usuarios")
        ref.child("${firebaseAuth.uid}")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val nombre = "${snapshot.child("nombres").value}"
                    val imagen = "${snapshot.child("urlFotoPerfil").value}"
                    val fechaNac = "${snapshot.child("fecha_nacimiento").value}"
                    val telefono = "${snapshot.child("telefono").value}"
                    val codTelefono = "${snapshot.child("codTelefono").value}"

                    //setear info
                    binding.EditextNombres.setText(nombre)
                    binding.EditextFechaNac.setText(fechaNac)
                    binding.EditextTelf.setText(telefono)

                    try {
                        Glide.with(applicationContext)
                            .load(imagen)
                            .placeholder(R.drawable.img_perfil)
                            .into(binding.imgPerfilUser)
                    } catch (e: Exception) {
                        Toast.makeText(
                            this@EditarPerfil,
                            "${e.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    try {
                        //convirte +34 a 34
                        val codigo = codTelefono.replace("+", "").toInt()
                        binding.selecCodigo.setCountryForPhoneCode(codigo)

                    } catch (e: Exception) {
                        Toast.makeText(
                            this@EditarPerfil,
                            "${e.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })
    }

    //fun para cambiar foto perfil desde galeria o telf, cuando seleccionemos en el floatActionButtonCambiarImg
    private fun select_img_de() {
        val popupMenu = PopupMenu(this, binding.floatActionButtonCambiarImg)

        popupMenu.menu.add(Menu.NONE, 1, 1, "Cámara")
        popupMenu.menu.add(Menu.NONE, 2, 2, "Gallería de Fotos")


        popupMenu.show()

        popupMenu.setOnMenuItemClickListener { item ->
            val itemId = item.itemId
            if (itemId == 1) {
                //Abrir camara
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    darPermisoCamara.launch(arrayOf(android.Manifest.permission.CAMERA))
                } else {
                    darPermisoCamara.launch(
                        arrayOf(
                            android.Manifest.permission.CAMERA,
                            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                }
            } else if (itemId == 2) {
                //abrir galeria de fotos
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    imgGaleria()
                } else {
                    darPermisosAlm.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }

            }
            return@setOnMenuItemClickListener true
        }
    }

    private val darPermisoCamara =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { resultado ->
            var todosPermisos = true
            for (concedido in resultado.values) {
                todosPermisos = todosPermisos && concedido
            }
            if (todosPermisos) {
                imgCamara()
            } else {
                Toast.makeText(
                    this,
                    "Permiso de la cámara no aprobado",
                    Toast.LENGTH_SHORT
                ).show()
            }

        }

    private fun imgCamara() {
        val contentValues = ContentValues()
        contentValues.put(MediaStore.Images.Media.TITLE, "Titulo_imagen")
        contentValues.put(MediaStore.Images.Media.DESCRIPTION, "Descripcion_imagen")

        imageUri =
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
    }

    private val resultadoCamara_ARL =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { resultado ->
            //ver si la img ha sido capturada
            if (resultado.resultCode == Activity.RESULT_OK) {
                try {
                    Glide.with(this)
                        .load(imageUri)
                        .placeholder(R.drawable.img_perfil)
                        .into(binding.imgPerfilUser)
                } catch (e: Exception) {

                }
            } else {
                Toast.makeText(
                    this,
                    "Fallido",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }


    private val darPermisosAlm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
            if (concedido) {
                imgGaleria()
            } else {
                Toast.makeText(
                    this,
                    "Permiso del almacenamiento no aprobado",
                    Toast.LENGTH_SHORT
                ).show()
            }

        }

    private fun imgGaleria() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*" // cuando abramos la galeria solo saldran img
        //llamamos fun resultadoGaleria
        resultadoGaleria_ARL.launch(intent)

    }

    private val resultadoGaleria_ARL =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()){resultado->
            if(resultado.resultCode == Activity.RESULT_OK) {
                val data = resultado.data
                imageUri = data!!.data



                try {
                    Glide.with(this)
                        .load(imageUri)
                        .placeholder(R.drawable.img_perfil)
                        .into(binding.imgPerfilUser)
                } catch (e: Exception) {

                }
            }else{
                    Toast.makeText(
                        this,
                        "Fallido",
                        Toast.LENGTH_SHORT
                    ).show()
            }
        }
}