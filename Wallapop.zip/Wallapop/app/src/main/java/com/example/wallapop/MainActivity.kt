package com.example.wallapop

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wallapop.Fragmentos.FragmentChats
import com.example.wallapop.Fragmentos.FragmentCuenta
import com.example.wallapop.Fragmentos.FragmentInicio
import com.example.wallapop.Fragmentos.FragmentMisAnuncios
import com.example.wallapop.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        //acceder a la vista que contiene nuestro main activity
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        comprobarSesion()

        //primer fragmento en visualizarse sera el de inicio
        verFragmentInicio()

        binding.BottomNavigView.setOnItemReselectedListener { item ->
            //ver cuando el usuario ha seleccionado una opcion especifico, devuelve true
            when (item.itemId){
                R.id.Item_Inicio -> {
                    verFragmentInicio()
                    true
                }

                R.id.Item_Chats -> {
                    verFragmentChats()
                    true
                }

                R.id.Item_Misanuncios -> {
                    verFragmentMisAnuncios()
                    true
                }

                R.id.Item_Cuenta -> {
                    verFragmentCuenta()
                    true
                }
                else -> {
                    false
                }
            }
        }
        }

    //comprobar usuario dentor de una actv.
    private fun comprobarSesion(){
        if(firebaseAuth.currentUser == null){
            startActivity(Intent(this, OpcionesLogin::class.java))
            finishAffinity()
        }
    }

    //funcion verFragmentInicio()

    private fun verFragmentInicio(){
        binding.TituloRelativeLayout.text = "Inicio"
        val fragment = FragmentInicio()
        val fragmentTransition = supportFragmentManager.beginTransaction()
        fragmentTransition.replace(binding.FragmentL1.id, fragment, "FragmentInicio")
        fragmentTransition.commit()

    }

    //funcion ver verFragmentChats()

    private fun verFragmentChats(){
        binding.TituloRelativeLayout.text = "Chats"
        val fragment = FragmentChats()
        val fragmentTransition = supportFragmentManager.beginTransaction()
        fragmentTransition.replace(binding.FragmentL1.id, fragment, "FragmentChats")
        fragmentTransition.commit()

    }

    //funcion verFragmentMisanunicios()

    private fun verFragmentMisAnuncios(){
        binding.TituloRelativeLayout.text = "Mis anuncios"
        val fragment = FragmentMisAnuncios()
        val fragmentTransition = supportFragmentManager.beginTransaction()
        fragmentTransition.replace(binding.FragmentL1.id, fragment, "FragmentMisAnuncios")
        fragmentTransition.commit()

    }

    //funcion verFragmentCuenta()

    private fun verFragmentCuenta(){
        binding.TituloRelativeLayout.text = "Cuenta"
        val fragment = FragmentCuenta()
        val fragmentTransition = supportFragmentManager.beginTransaction()
        fragmentTransition.replace(binding.FragmentL1.id, fragment, "FragmentInicio")
        fragmentTransition.commit()

    }


    }
