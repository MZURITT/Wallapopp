package com.example.wallapop

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wallapop.Opciones_login.Login_mail
import com.example.wallapop.databinding.ActivityMainBinding
import com.example.wallapop.databinding.ActivityOpcionesLoginBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.ActionCodeResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.FirebaseDatabase

class OpcionesLogin : AppCompatActivity() {

    private lateinit var binding: ActivityOpcionesLoginBinding

    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOpcionesLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Espera un momento...")
        progressDialog.setCanceledOnTouchOutside(false)



        firebaseAuth = FirebaseAuth.getInstance()
        comprobarSesion()

        //configurar opciones de inicios de sesión
        val google_sop = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        mGoogleSignInClient = GoogleSignIn.getClient(this, google_sop)


        /*dirigir a login mail al click al button*/
        binding.AccederEmail.setOnClickListener{
            startActivity(Intent(this@OpcionesLogin, Login_mail::class.java))
        }

        binding.AccederGoogle.setOnClickListener{
            googleLogin()
        }

    }

    private fun googleLogin() {
        val googleSignIntent = mGoogleSignInClient.signInIntent
        googleSignARL.launch(googleSignIntent)
    }

    private val googleSignARL = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()){resultado->
        if (resultado.resultCode == RESULT_OK){
            val data = resultado.data
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val cuenta = task.getResult(ApiException::class.java)
                autenticacionGoogle(cuenta.idToken)

            }catch (e:Exception){
                Toast.makeText(this, "${e.message}", Toast.LENGTH_SHORT).show()
            }


        }

    }
    //le pasamos como parametro tipo string
    private fun autenticacionGoogle(idToken: String?) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        firebaseAuth.signInWithCredential(credential)
            .addOnSuccessListener {resultadoAuth->
                if (resultadoAuth.additionalUserInfo!!.isNewUser){
                    completarInfobd()
                }else{
                    startActivity(Intent(this, MainActivity::class.java))
                    finishAffinity()
                }

            }
            .addOnFailureListener{e->
                Toast.makeText(this, "${e.message}", Toast.LENGTH_SHORT).show()

            }
    }

    private fun completarInfobd() {
        progressDialog.setMessage("Guardando info...")
        //Datos del user

        val tiempo = FuncionesConstates.obtenerTiempoDispositivo()
        //obtener mail de user registrado
        val emailUser = firebaseAuth.currentUser!!.email
        val  uidUsuario = firebaseAuth.uid
        val nombreUsuario = firebaseAuth.currentUser?.displayName

        val hashMap = HashMap<String, Any>()
        hashMap["nombres"] = "${nombreUsuario}"
        hashMap["codTelefono"] = ""
        hashMap["telefono"] = ""
        hashMap["urlFotoPerfil"] = ""
        hashMap["proveedorAcceso"] = "Google"
        hashMap["escribiendoChat"] = ""
        hashMap["tiempo"] = tiempo
        hashMap["online"] = "true" //estado de user
        hashMap["mail"] = "${emailUser}"
        hashMap["uid"] = "${uidUsuario}"
        hashMap["fecha_nacimiento"] = ""

        //envio datos recogidos a firebase
        val ref = FirebaseDatabase.getInstance().getReference("Usuarios") //nombre bbdd
        ref.child(uidUsuario!!)
            .setValue(hashMap)//con esto le pasamos toda la info almacenada en el hasmpa dentro del iuid del user
            //registro usuario ok
            .addOnSuccessListener {
                progressDialog.dismiss()
                startActivity(Intent(this, MainActivity::class.java))
                finishAffinity()
            }
            //regustro usuario fallido
            .addOnFailureListener {e->
                progressDialog.dismiss()
                Toast.makeText(
                    this,
                    "No se ha registrado. Fallo: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }

    }

    private fun comprobarSesion(){
        if (firebaseAuth.currentUser != null){
            startActivity(Intent(this, MainActivity::class.java))
            finishAffinity()
        }
    }

}